/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tienda.servicios;

import java.util.ArrayList;
import tienda.persistencia.productoDao;

/**
 *
 * @author gonza
 */
public class serviciosProducto {
    
    private productoDao Dao;
  
   
    
    
     public ArrayList <String> ListarProductos() throws Exception{
       ArrayList<String> nombreProductos = null;
        try {
           
             nombreProductos.addAll( Dao.ListarProductos());
             
             return nombreProductos;
             
             
         } catch (Exception e)  {
             throw e;
         
         } 
        
     }
}

    

